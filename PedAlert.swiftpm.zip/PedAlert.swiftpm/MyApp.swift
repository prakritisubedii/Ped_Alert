import SwiftUI

@main
struct PedAlertApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
